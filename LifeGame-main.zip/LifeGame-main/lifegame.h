#ifndef _LIFE_GAME_H
#define _LIFE_GAME_H
#include "grid.h"
class LifeGame {
    int width, height;
    Grid* grid;

   public:
    LifeGame(int width, int height);
    ~LifeGame();
    void play();
};
#endif
