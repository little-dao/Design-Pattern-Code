#include "rule_three.h"

#include <iostream>
using namespace std;
RuleThree::RuleThree(Cell* component) : Decorator{component} {}

bool RuleThree::update(int cnt, int status) {
 //   clog << "@3" << cnt << endl;
    status = component->update(cnt, status);
    return cnt <=3 && status;
}
