#ifndef _RULETWO_
#define _RULETWO_

#include "cell.h"
#include "decorator.h"
class RuleTwo : public Decorator {
   public:
    explicit RuleTwo(Cell *component);
    bool update(int cnt, int status) override;
};

#endif
