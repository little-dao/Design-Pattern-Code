#ifndef _CELL_H
#define _CELL_H
#include <iostream>
#include <vector>
using namespace std;

class Cell {
   public:
    Cell();
    virtual bool update(int cnt,int status) = 0;
    virtual ~Cell() = 0;
};

#endif
