#include "cell.h"

Cell::Cell() {}
Cell::~Cell() {}
