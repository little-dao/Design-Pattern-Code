#include "friendly.h"

RuleFive::RuleFive(int n, Cell* component) : howmanyfriendsifancy{n}, Decorator{component} {}

bool RuleFive::update(int cnt, int status) {
    
    if (cnt == howmanyfriendsifancy)
    {
        component->update(cnt, status);
        return 1;
    }
    status = component->update(cnt, status);
    return status;
}
