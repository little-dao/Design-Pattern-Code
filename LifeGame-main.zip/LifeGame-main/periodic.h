#ifndef _RULEFOUR_
#define _RULEFOUR_

#include "cell.h"
#include "decorator.h"

class RuleFour : public Decorator {
    int round;
    int time;
   public:
    
    explicit RuleFour(int n, Cell* component);
    bool update(int cnt, int status) override;
};
#endif
