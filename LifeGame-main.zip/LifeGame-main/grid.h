#ifndef _GRID_H
#define _GRID_H
#include <vector>

#include "cell.h"
class Grid {
    int width, height;

   public:
    vector<vector<Cell*>> cells;
    vector<vector<int>> liveordie;
    Grid(int weight, int height);
    ~Grid();
    void update();
};
#endif
