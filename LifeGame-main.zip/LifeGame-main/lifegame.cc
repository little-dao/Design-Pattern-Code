#include "lifegame.h"

#include <iostream>

#include "friendly.h"
#include "periodic.h"
#include "rule_three.h"
#include "rule_two.h"

using namespace std;

class Grid;

LifeGame::LifeGame(int width, int height) : width{width}, height{height}, grid{new Grid(width, height)} {}

void LifeGame::play() {
    char cmd;
    int x, y;
    int N;
    int tt = 0;  // only use in debug
    while (cin >> cmd) {
        switch (cmd) {
            case 'u':
                // implies round has updated

                // Update to next generation
                grid->update();
                ++tt;
                break;
            case 'o':
                cin >> x >> y;
                // Force cell (x, y) to be alive in this current
                // generation.
                grid->liveordie.at(y).at(x) = 1;
                // obviously
                break;
            case 'l':
                cin >> x >> y;
                grid->cells.at(y).at(x) = new RuleTwo(grid->cells.at(y).at(x));
                // Add rule 2 to cell (x, y)
                break;
            case 'a':
                cin >> x >> y;
                // Add rule 3 to cell (x, y)
                grid->cells.at(y).at(x) = new RuleThree(grid->cells.at(y).at(x));
                break;
            case 't':
                cin >> x >> y >> N;
                // Add rule 4 to cell (x, y) with period N
                grid->cells.at(y).at(x) = new RuleFour(N, grid->cells.at(y).at(x));
                break;
            case 'f':
                cin >> x >> y >> N;
                // Add rule 5 to cell (x, y) with desired neighbours N
                grid->cells.at(y).at(x) = new RuleFive(N, grid->cells.at(y).at(x));
                break;
            case 'd': {
                vector<char> tmp;
                // Read in letters denoting the default ruleset to
                // apply to every cell in the grid.
                // l -> rule 2 from spec (underpopulation)
                // a -> rule 3 from spec (overpopulation)
                // p -> rule 4 from spec (periodic cell)
                // f -> rule 5 from spec (friendly cell)
                // Any other character = stop reading and set default
                // from rules currently read.

                // All these cells will be dead, so this also effectively
                // resets the game.

                // Example if you see "dal*" then you would set the
                // default for all cells to rule 3 + rule 2. Note that
                // this default is the "normal" game of life.

                // Another Example: "daf7-" would apply rule 3 then
                // rule 5 with N set to 7.
                int n = -1, m = -1;
                while (cin >> cmd) {
                    if (cmd == 'l') {
                        tmp.emplace_back(cmd);
                        continue;
                    }
                    if (cmd == 'a') {
                        tmp.emplace_back(cmd);
                        continue;
                    }
                    if (cmd == 'p') {
                        cin >> n;

                        tmp.emplace_back(cmd);
                        continue;
                    }
                    if (cmd == 'f') {
                        cin >> m;

                        tmp.emplace_back(cmd);
                        continue;
                    } else {
                        break;
                    }
                }

                for (int i = 0; i < height; i++) {
                    for (int j = 0; j < width; j++) {
                        grid->liveordie.at(i).at(j) = 0;

                        for (int t = 0; t < tmp.size(); t++) {
                            if (tmp.at(t) == 'l') {
                                grid->cells.at(i).at(j) = new RuleTwo(grid->cells.at(i).at(j));
                            }
                            if (tmp.at(t) == 'a') {
                                grid->cells.at(i).at(j) = new RuleThree(grid->cells.at(i).at(j));
                            }

                            if (tmp.at(t) == 'p') {
                                grid->cells.at(i).at(j) = new RuleFour(n, grid->cells.at(i).at(j));
                            }
                            if (tmp.at(t) == 'f') {
                                grid->cells.at(i).at(j) = new RuleFive(m, grid->cells.at(i).at(j));
                            }
                        }
                    }
                }
                tmp.clear();
                break;
            }
            case 'p':
                // Print the grid - living cells should be printed as
                // X's, while dead cells should be printed as .'s
                // cerr << endl<<tt<<endl;
                for (int i = 0; i < height; i++) {
                    for (int j = 0; j < width; j++) {
                        putchar((grid->liveordie.at(i).at(j) ? 'X' : '.'));
                    }
                    cout << endl;
                }
                break;
            case 'q':
                // Quit the program.
                return;
        }
    }
}

LifeGame::~LifeGame() {
    delete grid;
}
