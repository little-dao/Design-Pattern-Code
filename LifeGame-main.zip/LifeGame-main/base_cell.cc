#include "base_cell.h"

#include <iostream>
using namespace std;
bool BaseCell::update(int cnt, int status) {
    return cnt == 3||status;
}

// same fields of basecell and cell, so using default ctor is fine

// same for dtor, since vector will auto delete itself
BaseCell::~BaseCell() {}
