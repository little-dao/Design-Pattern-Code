#include "grid.h"

#include <vector>

#include "base_cell.h"

Grid::Grid(int width, int height) : width{width}, height{height}, cells{} {
    // create cells
    for (int i = 0; i < height; i++) {
        vector<Cell*> l{};
        cells.emplace_back(l);
        for (int j = 0; j < width; j++) {
            cells.at(i).emplace_back(new BaseCell);
        }
        liveordie.emplace_back(vector<int>(width, 0));
    }
}

Grid::~Grid() {
    for (int i = 0; i < height; i++) {
        for (int j = 0; j < width; j++) {
            delete cells.at(i).at(j);
        }
    }
}


void Grid::update() {
    vector<vector<int>> temp = liveordie;
    const int dt[] = { 0,1,-1 };
    for (int i = 0; i < height; i++) {
        for (int j = 0; j < width; j++)
        {
            int cnt = 0;
            auto f = [&](int x,int y) {
                if(x>=0&&x<height&&y>=0&&y<width)
                return 1;
                return 0;
            };
            for(int ii=0;ii<3;++ii)
                for (int jj = 0; jj < 3; ++jj)
                {
                    if (ii == 0 && jj == 0)continue;
                    if (f(i + dt[ii], j + dt[jj]))
                        cnt += temp[i + dt[ii]][j + dt[jj]]; 
                }
         //   clog << cnt<<endl;
            liveordie[i][j] = cells[i][j]->update(cnt, liveordie[i][j]);
        }
    }
}
