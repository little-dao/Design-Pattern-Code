#ifndef _BASE_CELL_H
#define _BASE_CELL_H
#include "cell.h"
class BaseCell : public Cell {
   public:
    bool update(int cnt, int status) override;
    ~BaseCell();
};
#endif
