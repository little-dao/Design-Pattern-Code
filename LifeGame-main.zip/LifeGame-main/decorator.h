#ifndef _DEC_H
#define _DEC_H
#include "cell.h"

class Decorator : public Cell {
   protected:
    Cell *component;

   public:
       Decorator(Cell *component);
    virtual ~Decorator();
};

#endif
