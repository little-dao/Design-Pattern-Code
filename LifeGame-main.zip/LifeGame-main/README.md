# LifeGame
a game of cells with many rules applie, further play usage can be found in a4.pdf
