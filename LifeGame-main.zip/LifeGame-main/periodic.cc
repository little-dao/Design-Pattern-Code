#include "periodic.h"

RuleFour::RuleFour(int n, Cell* component) : time{0},round{n}, Decorator{component} {}

// I have NO static member named time, whenever update is called in lifegame, time is incremented
bool RuleFour::update(int cnt, int status) {
    
    ++time;
  //  clog << "@4" << cnt << endl;
 //   clog << "@44" << time << " " << round << endl;
    if (time % round == 0)
    {
   //     clog << cnt << " " << status << endl;
        component->update(cnt, status);
        return 1 - status;
    }
    status = component->update(cnt, status);
    return status;
}
