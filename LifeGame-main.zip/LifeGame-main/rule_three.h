#ifndef _RULETHREE_
#define _RULETHREE_

#include "cell.h"
#include "decorator.h"

class RuleThree : public Decorator {
   public:
    explicit RuleThree(Cell* component);
    bool update(int cnt, int status) override;
};
#endif
