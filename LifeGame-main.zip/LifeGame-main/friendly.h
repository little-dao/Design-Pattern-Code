#ifndef _RULEFIVE_
#define _RULEFIVE_

#include "cell.h"
#include "decorator.h"

class RuleFive : public Decorator {
    int howmanyfriendsifancy;

   public:
    explicit RuleFive(int n, Cell* component);
    bool update(int cnt, int status) override;
};
#endif
