#include "rule_two.h"

#include <iostream>

#include "cell.h"
using namespace std;
RuleTwo::RuleTwo(Cell* component) : Decorator{component} {}

bool RuleTwo::update(int cnt, int status) {
  //  clog << "@2"<<cnt << endl;
    status=component->update(cnt,status);
    return cnt >= 2 && status;
}
