#include "grid.h"

#include <iostream>
#include <vector>

#include "cell.h"
#include "info.h"
#include "state.h"
#include "textdisplay.h"
using namespace std;
Grid::~Grid() {
    delete td;
}

void Grid::setObserver(Observer<Info, State>* ob) {
    this->ob = ob;
}

bool Grid::isFull() const {
    for (int i = 0; i < theGrid.size(); i++) {
        for (int j = 0; j < theGrid.at(i).size(); j++) {
            if (theGrid.at(i).at(j).getInfo().colour == Colour::NoColour) {
                return false;
            }
        }
    }
    return true;
}

Colour Grid::whoWon() const {
    int white = 0;
    int black = 0;
    for (int i = 0; i < theGrid.size(); i++) {
        for (int j = 0; j < theGrid.at(i).size(); j++) {
            if (theGrid.at(i).at(j).getInfo().colour == Colour::White) {
                white++;
            }
            if (theGrid.at(i).at(j).getInfo().colour == Colour::Black) {
                black++;
            }
        }
    }

    if (white >= black) {
        cout << "White wins!" << endl;
        return Colour::White;
    } else {
        cout << "Black wins!" << endl;
        return Colour::Black;
    }
}
void Grid::init(size_t n) {
    for (int i = 0; i < theGrid.size(); i++) theGrid[i].clear();
    theGrid.clear();
    delete td;
    // create cells
    int m = n;
    td = new TextDisplay(m);

    for (int i = 0; i < n; i++) {
        vector<Cell> tmp{};
        theGrid.emplace_back(tmp);
        for (int j = 0; j < n; j++) {
            theGrid.at(i).emplace_back(Cell(i, j));
        }
    }

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            theGrid.at(i).at(j).attach(td);

            if ((i - 1) >= 0) {
                if ((j - 1) >= 0) {
                    theGrid.at(i).at(j).attach(&theGrid[i - 1][j - 1]);
                }
                theGrid.at(i).at(j).attach(&theGrid[i - 1][j]);
                if ((j + 1) < n) {
                    theGrid.at(i).at(j).attach(&theGrid[i - 1][j + 1]);
                }
            }
            if ((i + 1) < n) {
                if ((j - 1) >= 0) {
                    theGrid.at(i).at(j).attach(&theGrid[i + 1][j - 1]);
                }
                theGrid.at(i).at(j).attach(&theGrid[i + 1][j]);
                if ((j + 1) < n) {
                    theGrid.at(i).at(j).attach(&theGrid[i + 1][j + 1]);
                }
            }
            if ((j - 1) >= 0) {
                theGrid.at(i).at(j).attach(&theGrid[i][j - 1]);
            }
            if (j + 1 < n) {
                theGrid.at(i).at(j).attach(&theGrid[i][j + 1]);
            }
        }
    }
    int mid = m / 2;
    theGrid.at(mid - 1).at(mid - 1).setPiece(Colour::Black);
    theGrid.at(mid - 1).at(mid).setPiece(Colour::White);
    theGrid.at(mid).at(mid - 1).setPiece(Colour::White);
    theGrid.at(mid).at(mid).setPiece(Colour::Black);
    // setting starting colour
}

void Grid::setPiece(size_t r, size_t c, Colour colour) {
    if (theGrid.at(r).at(c).getInfo().colour != Colour::NoColour) {
        throw InvalidMove{};
    }
    theGrid.at(r).at(c).setPiece(colour);
    td->notify(theGrid.at(r).at(c));
}

void Grid::toggle(size_t r, size_t c) {
    theGrid.at(r).at(c).toggle();
    td->notify(theGrid.at(r).at(c));
}

std::ostream& operator<<(std::ostream& out, const Grid& g) {
    out << *(g.td);
    return out;
}
