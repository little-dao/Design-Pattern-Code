#include "textdisplay.h"

#include <iostream>

#include "subject.h"
TextDisplay::TextDisplay(int n) : gridSize{n} {
    for (int i = 0; i < n; i++) {
        std::vector<char> c;
        for (int j = 0; j < n; j++) c.emplace_back('-');
        theDisplay.push_back(c);
    }
    // theDisplay.resize(gridSize, std::vector<char>(gridSize, '-'));
}

void TextDisplay::notify(Subject<Info, State> &whoNotified) {
    if (whoNotified.getInfo().colour == Colour::Black) {
        theDisplay.at(whoNotified.getInfo().row).at(whoNotified.getInfo().col) = 'B';
    } else if (whoNotified.getInfo().colour == Colour::NoColour) {
        theDisplay.at(whoNotified.getInfo().row).at(whoNotified.getInfo().col) =
            '-';
    } else if (whoNotified.getInfo().colour == Colour::White) {
        theDisplay.at(whoNotified.getInfo().row).at(whoNotified.getInfo().col) = 'W';
    }
}
std::ostream &
operator<<(std::ostream &out, const TextDisplay &td) {
    for (int i = 0; i < td.gridSize; i++) {
        for (int j = 0; j < td.gridSize; j++) {
            out << td.theDisplay.at(i).at(j);
        }
        out << std::endl;
    }
    return out;
}
