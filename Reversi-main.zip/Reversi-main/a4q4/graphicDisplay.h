#ifndef GRAPHIC
#define GRAPHIC
#include <vector>

#include "info.h"
#include "observer.h"
#include "state.h"
#include "window.h"

class Cell;

class GraphicDisplay : public Observer<Info, State> {
    Xwindow x;
    int dimension;

   public:
    GraphicDisplay(int n);

    void notify(Subject<Info, State> &whoNotified) override;
    ~GraphicDisplay();
};
#endif
