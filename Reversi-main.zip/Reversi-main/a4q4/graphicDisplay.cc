#include "graphicDisplay.h"

#include "subject.h"
#include "window.h"
GraphicDisplay::GraphicDisplay(int dimension) : x{}, dimension{dimension} {
    for (int i = 0; i < dimension; i++) {
        for (int j = 0; j < dimension; j++) {
            x.fillRectangle(i, j, 500, 500, 4);
        }
    }
}

void GraphicDisplay::notify(Subject<Info, State> &whoNotified) {
    int pos = 500 / dimension;
    if (whoNotified.getInfo().colour == Colour::Black) {
        x.fillRectangle(whoNotified.getInfo().col * pos, whoNotified.getInfo().row * pos, pos, pos, 1);
    } else if (whoNotified.getInfo().colour == Colour::White) {
        x.fillRectangle(whoNotified.getInfo().col * pos, whoNotified.getInfo().row * pos, pos, pos, 0);
    }
}

GraphicDisplay::~GraphicDisplay() {
}
