#include "cell.h"

#include <iostream>
using namespace std;
Cell::Cell(size_t r, size_t c) : r{r}, c{c}, colour{Colour::NoColour} {
    setState(State{StateType::NewPiece, Colour::NoColour});
}

void Cell::setPiece(Colour colour) {
    this->colour = colour;
    setState(State{StateType::NewPiece, colour});
    notifyObservers();
}

void Cell::toggle() {
    if (colour == Colour::Black) {
        colour = Colour::White;
    } else if (colour == Colour::White) {
        colour = Colour::Black;
    }
}

Direction Cell::checkDirection(Subject<Info, State> &whoFrom) {
    Info winfo = whoFrom.getInfo();
    if (winfo.row == r) {
        if (winfo.col > c) {
            return Direction::E;
        } else if (winfo.col < c) {
            return Direction::W;
        }
    } else if (winfo.row > r) {
        if (winfo.col > c) {
            return Direction::SE;
        } else if (winfo.col == c) {
            return Direction::S;
        } else if (winfo.col < c) {
            return Direction::SW;
        }
    } else if (winfo.row < r) {
        if (winfo.col > c) {
            return Direction::NE;
        } else if (winfo.col == c) {
            return Direction::N;
        } else if (winfo.col < c) {
            return Direction::NW;
        }
    }
}

Direction Cell::reverse_dir(Direction dir) {
    if (dir == Direction::N) {
        return Direction::S;
    } else if (dir == Direction::S) {
        return Direction::N;
    } else if (dir == Direction::SE) {
        return Direction::NW;
    } else if (dir == Direction::SW) {
        return Direction::NE;
    } else if (dir == Direction::NE) {
        return Direction::SW;
    } else if (dir == Direction::NW) {
        return Direction::SE;
    } else if (dir == Direction::E) {
        return Direction::W;
    } else if (dir == Direction::W) {
        return Direction::E;
    }
}
void Cell::notify(Subject<Info, State> &whoFrom) {
    if (this->colour == Colour::NoColour) {
        return;
    }
    // new piece been placed and notifying others
    if (whoFrom.getState().type == StateType::NewPiece) {
        // same colour
        if (whoFrom.getState().colour == this->colour) {
            setState({StateType::Reply, whoFrom.getState().colour, checkDirection(whoFrom)});
        }
        // different colour
        else {
            this->setState({StateType::Relay, whoFrom.getState().colour, checkDirection(whoFrom)});
            notifyObservers();
        }
        // notifyObservers();

        // keep notifying others that I am the different piece of new piece
    } else if (whoFrom.getState().type == StateType::Relay) {
        // if the subject and observer direction are the same:continue
        if (checkDirection(whoFrom) == whoFrom.getState().direction) {
            if (whoFrom.getState().colour == this->colour) {
                // key part, I set a new piece, everyone is different colour in the notification line(adjacent),
                // however, I am experiencing the same colour(reply) now, thus I am notifying in reverse direction, and everyone change their colour lsnow.
                this->setState({StateType::Reply, whoFrom.getState().colour, whoFrom.getState().direction});
                notifyObservers();
                // reverse(send back )to the obs.
            } else {
                this->setState({StateType::Relay, whoFrom.getState().colour, whoFrom.getState().direction});
                notifyObservers();
            }
        }
        // getting Reply in backward direction
    } else {
        State mstat = getState();
        if (reverse_dir(checkDirection(whoFrom)) == whoFrom.getState().direction) {
            if ((mstat.direction == whoFrom.getState().direction) &&
                (mstat.type == StateType::Relay) &&
                (mstat.colour == whoFrom.getState().colour)) {
                setState({StateType::Reply, mstat.colour, mstat.direction});

                if (getInfo().colour != mstat.colour) {
                    toggle();
                }
                notifyObservers();
            }
        }
    }
}

Info Cell::getInfo() const {
    return Info{r, c, colour};
}
