# Reversi

Written with C++, as you can have grphical display enabled by using the program from a4q4 folder, with command ./reversi display display
