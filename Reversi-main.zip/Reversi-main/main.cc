#include <iostream>
#include <string>
// You may include other allowed headers, as needed
#include "grid.h"
#include "state.h"
using namespace std;

// Do not remove any code; do not add code other than where indicated.

int main(int argc, char *argv[]) {
    cin.exceptions(ios::eofbit | ios::failbit);
    string cmd;
    Grid g;
    Colour mcolour = Colour::Black;
    int board = 0;
    // Add code here
    int newed = 0;
    try {
        while (true) {
            cin >> cmd;
            if (cmd == "new") {
                int n;
                cin >> n;
                if ((n >= 4) && (n % 2 == 0)) {
                    g.init(n);
                    newed = 1;
                    board = n;
                }
                cout << g;
                // Add code here
            } else if (cmd == "play") {
                if (newed == 1) {
                    int r = 0, c = 0;
                    cin >> r >> c;
                    // check validMove or not
                    try {
                        if ((r < 0) || (r >= board) || (c < 0) || (c >= board)) {
                            throw InvalidMove{};
                        }

                        g.setPiece(r, c, mcolour);
                        if (mcolour == Colour::Black) {
                            mcolour = Colour::White;
                        } else if (mcolour == Colour::White) {
                            mcolour = Colour::Black;
                        }
                        cout << g;

                    } catch (InvalidMove &e) {
                    }

                    if (g.isFull()) {
                        g.whoWon();
                        break;
                    }
                }
            }
        }
    } catch (ios::failure &) {
    }  // Any I/O failure quits
}
