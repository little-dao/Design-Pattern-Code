#ifndef _WORDLE_H_
#define _WORDLE_H_
#include "termcodes.h"

struct Wordle {
    // secrete code
    char* code;
    // length of code(self-defined field)
    int len;
    // regualr ctor
    Wordle(char* code);
    // dtor
    ~Wordle();
    // method of play Game
    void playGame();
};

#endif
