#include "wordle.h"

#include <iomanip>
#include <iostream>
#include <string>
using namespace std;

// regular ctor
Wordle::Wordle(char* code) : code{code} {
    string temp{code};
    len = temp.length();
}

// using default desctor, since the heap array I used is not in the field
Wordle::~Wordle(){};

// game function
void Wordle::playGame() {
    string str;
    string s_code{code};
    // starting attempt
    int counter = 0;
    // print this first whenever game started

    cout << "Enter " << this->len << " length word as guess: ";

    while (cin >> str) {
        if (counter <= 5) {
            // wrong length , do not count as attempt
            if ((int)str.length() != (int)this->len) {
                cout << "Incorrect guess size, please enter guess of length " << len << ": ";
            }
            // correct length,check for correctness
            else {
                if (str == s_code) {
                    for (int i = 0; i < len; i++) {
                        cout << GREEN << str[i];
                        cout << RESET;
                    }
                    cout << endl;
                    cout << "Congrats you found the word!" << endl;
                    return;
                }

                counter++;
                // store the printing color of input:
                // 0 is reset, 1 is green, 2 is yellow
                string right = str;
                string occupied = str;
                string s_occupied = str;
                for (int i = 0; i < len; i++) {
                    // output colour
                    right[i] = 0;
                    // occupied for input string
                    occupied[i] = 0;
                    // occupied of secrete code
                    s_occupied[i] = 0;
                }
                // mark for green pos
                for (int i = 0; i < len; i++) {
                    if (str[i] == s_code[i]) {
                        right[i] = 1;
                        occupied[i] = 1;
                        s_occupied[i] = 1;
                    }
                }

                // checking for yellow and grey
                for (int i = 0; i < len; i++) {
                    // implies input string pos is correct
                    if (occupied[i] != 1) {
                        for (int j = 0; j < len; j++) {
                            // matches in wrong pos, since occupied marked for s_code
                            if ((str[i] == s_code[j]) && (s_occupied[j] != 1)) {
                                // mark yellow
                                s_occupied[j] = 1;
                                occupied[i] = 1;
                                right[i] = 2;
                                break;
                            }
                        }
                    }
                }

                // print
                for (int i = 0; i < len; i++) {
                    if (right[i] == 0) {
                        cout << str[i];

                    } else if (right[i] == 1) {
                        cout << GREEN << str[i];
                        cout << RESET;

                    } else {
                        cout << YELLOW << str[i];
                        cout << RESET;
                    }
                }
                cout << endl;

                if (counter <= 5) {
                    cout << "Enter " << this->len << " length word as guess: ";
                }
            }
        }
    }
    // if counter has been greater than 5: if it's been guessed correctly, return, else it will always print as exec:
    cout << "Out of guesses! The word was: " << s_code << endl;
    return;
}
