# include "Human.h"

Human::Human(int HP,int ATK,int DEF, Entity* protector, bool hard,Cell* currentCell){};

Human::~Human(){};
