# include "Werewolf.h"
using namespace std;

Werewolf::Werewolf(int HP,int ATK,int DEF, Entity* protector, bool hard,Cell* currentCell, bool compassHolder){};

void Werewolf::attackPlayer(Player*){};

Werewolf::~Werewolf(){};
