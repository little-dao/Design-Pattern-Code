# include "Goblin.h"
using namespace std;

Goblin::Goblin(int HP,int ATK,int DEF, Entity* protector, bool hard,Cell* currentCell, bool compassHolder){};

void Goblin::attackPlayer(Player*){};

Goblin::~Goblin(){};
