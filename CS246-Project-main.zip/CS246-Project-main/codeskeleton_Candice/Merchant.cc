# include "Merchant.h"

bool Merchant::M_hostile = false;

Merchant::Merchant(int HP,int ATK,int DEF, Entity* protector, bool hard, Cell* currentCell, bool compassHolder){};

void Merchant::attackPlayer(Player*){};

Merchant::~Merchant(){};
