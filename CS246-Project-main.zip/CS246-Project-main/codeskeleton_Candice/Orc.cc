# include "Orc.h"

Orc::Orc(int HP,int ATK,int DEF, Entity* protector, bool hard,Cell* currentCell){};

Orc::~Orc(){};
