# include "Enemy.h"
# include "Player.h"
using namespace std;

Cell* Enemy::setAggroTrigger(){};

void Enemy::moveRandom(){};

void Enemy::attackPlayer(Player*){};

void Enemy::update(){};

void kill(){};

Enemy::~Enemy(){};
